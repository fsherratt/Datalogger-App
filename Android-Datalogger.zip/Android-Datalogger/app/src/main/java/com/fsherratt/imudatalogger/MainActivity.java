package com.fsherratt.imudatalogger;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import no.nordicsemi.android.support.v18.scanner.BluetoothLeScannerCompat;
import no.nordicsemi.android.support.v18.scanner.ScanSettings;
import no.nordicsemi.android.support.v18.scanner.ScanFilter;
import no.nordicsemi.android.support.v18.scanner.ScanCallback;
import no.nordicsemi.android.support.v18.scanner.ScanResult;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    public final static String ACTION_KEYFRAME_LABEL = "com.fsherratt.imudatalogger.ACTION_KEYFRAME_LABEL";
    public final static String EXTRA_LABEL = "com.fsherratt.imudatalogger.EXTRA_LABEL";
    public final static String EXTRA_TIMESTAMP = "com.fsherratt.imudatalogger.EXTRA_TIMESTAMP";

    // Lifecycle code
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        startReceiver();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopScanner();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopScanner();
        stopReceiver();

        disconnectAllDevices();
    }


    // UI Elements
    public void device_scan_button(View view) {
        Log.d(TAG, "device_scan_button: Scan for devices");
        toggleScanner();
    }

    public void device_connect_button(View view) {
        Log.d(TAG, "device_connect_button: Pushed");
        connectToDevices();
    }

    public void device_disconnect_button(View view) {
        Log.d(TAG, "Device_disconnect_button: Pushed");
        disconnectAllDevices();
    }

    public void start_record_button(View view) {
        Log.d(TAG, "start_record_button: Pushed");
        startRecording();
    }

    public void stop_record_button(View view) {
        Log.d(TAG, "stop_record_button: Pushed");
        stopRecording();
    }


    // BLE Scanner
    private boolean mScanning;
    private final List<BluetoothDevice> mDevices = new ArrayList<>();

    public boolean toggleScanner() {
        if (!mScanning)
            startScanner();
        else
            stopScanner();

        return mScanning;
    }

    public void startScanner() {
        if (mScanning)
            return;

        BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        ScanSettings settings = new ScanSettings.Builder()
                .setLegacy(false)
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(1000)
                .setUseHardwareBatchingIfSupported(true)
                .build();
        List<ScanFilter> filters = new ArrayList<>();
        scanner.startScan(filters, settings, mScanCallback);

        Log.d(TAG, "stopScanner: Scan started");
        mScanning = true;
    }

    public void stopScanner() {
        if (!mScanning)
            return;

        final BluetoothLeScannerCompat scanner = BluetoothLeScannerCompat.getScanner();
        scanner.stopScan(mScanCallback);

        Log.d(TAG, "stopScanner: Scan stopped");
        mScanning = false;
    }

    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(final int callbackType, final ScanResult result) {
            // empty
            Log.d(TAG,"onScanResult: " + result.getDevice().getName() + " " + result.getDevice().getAddress());
        }

        @Override
        public void onBatchScanResults(final List<ScanResult> results) {
            BluetoothDevice device;

            for (final ScanResult result : results) {
                device = result.getDevice();
                String name = device.getName();

                if (name == null)
                    continue;

                if (!device.getName().contains("Movesense"))
                    continue;

                if (!mDevices.contains(device)) {
                    mDevices.add(device);
                    Log.d(TAG, "onBatchScanResults: Added device: " + device.getName() + " " + device.getAddress());
                }
            }
        }

        @Override
        public void onScanFailed(final int errorCode) {
            // empty
        }
    };


    // BLE Connection
    private List<BleServiceHolder> mBleServices = new ArrayList<>();
    private static HashMap<String, BleServiceHolder> mConnectedDevices = new HashMap();

    public void disconnectAllDevices() {
        if ( mBleServices.size() == 0 ) {
            Log.d(TAG, "disconnectAllDevices: No devices connected");
            return;
        }

        for ( BleServiceHolder bleService : mBleServices ) {
            bleService.stopService();
        }
    }

    public void connectToDevices() {
        stopScanner();

        if ( mDevices.size() == 0 ) {
            Log.d(TAG, "connectToDevices: No devices");
            return;
        }

        for ( BluetoothDevice device : mDevices ) {
            mBleServices.add( new BleServiceHolder(this, device ));
            mConnectedDevices.put(device.getAddress(), mBleServices.get(mBleServices.size() - 1));
        }
    }

    public void startRecording() {
        if (mBleServices.size() == 0) {
            Toast.makeText(this, "No devices connected", Toast.LENGTH_SHORT).show();
            return;
        }

        for (BleServiceHolder bleService : mBleServices) {
            bleService.startRecording();
        }
    }

    public void stopRecording() {
        if ( mBleServices.size() == 0 ) {
            Toast.makeText(this, "No devices connected", Toast.LENGTH_SHORT).show();
            return;
        }

        for ( BleServiceHolder bleService : mBleServices ) {
            bleService.stopRecording();
        }
    }


    // Incoming BLE Status
    private void startReceiver() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(bleService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(bleService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(bleService.ACTION_GATT_SERVICES_DISCOVERED);

        try {
            registerReceiver(mGattUpdateReceiver, intentFilter);
            Log.d(TAG, "startReceiver: ACTION_DATA_AVAILABLE receiver listening");
        } catch(IllegalArgumentException e) {
            Log.e(TAG, "Receiver already registered");
        }
    }

    private void stopReceiver() {
        try {
            unregisterReceiver(mGattUpdateReceiver);
            Log.d(TAG, "stopReceiver: ACTION_DATA_AVAILABLE receiver stopped");
        } catch(IllegalArgumentException e) {
            Log.e(TAG, "Receiver not registered");
        }
    }

    private final BroadcastReceiver mGattUpdateReceiver; {
        mGattUpdateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                final String action = intent.getAction();

                if (action == null)
                    return;

                switch (action) {
                    case bleService.ACTION_GATT_CONNECTED:
                        Log.d(TAG, "onReceive: ACTION_GATT_CONNECTED");

                        break;
                    case bleService.ACTION_GATT_DISCONNECTED:
                        Log.d(TAG, "onReceive: ACTION_GATT_DISCONNECTED");

                        // Tidy up after disconnection
                        String address = intent.getStringExtra(bleService.EXTRA_ADDRESS);

                        mBleServices.remove(mConnectedDevices.get(address));
                        mConnectedDevices.remove(address);

                        Log.d(TAG, "onReceive: Device " + address + " closed");

                        break;

                    case bleService.ACTION_GATT_SERVICES_DISCOVERED:
                        Log.d(TAG, "onReceive: ACTION_GATT_SERVICES_DISCOVERED");

                        break;
                }
            }
        };
    }
}

class BleServiceHolder {
    private static final String TAG = "BleServiceHolder";

    private Context mContext;

    private BluetoothDevice mDevice;
    private bleService mBluetoothLeService;
    boolean mBound = false;

    BleServiceHolder(Context context, BluetoothDevice newDevice) {
        mContext = context;
        mDevice = newDevice;

        String deviceAddress = mDevice.getAddress();

        final BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();

        final BluetoothDevice device = adapter.getRemoteDevice(deviceAddress);

        Intent bleServiceIntent = new Intent(mContext, bleService.class);
        bleServiceIntent.putExtra(bleService.EXTRA_ADDRESS, device.getAddress());
        bleServiceIntent.putExtra(bleService.EXTRA_NAME, device.getName());

        mContext.bindService(bleServiceIntent, mServiceConnection, mContext.BIND_AUTO_CREATE);
    }

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service){
            bleService.LocalBinder binder = (bleService.LocalBinder) service;
            mBluetoothLeService = binder.getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                return;
            }

            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect();

            mBound = true;
            Log.d(TAG, "onServiceConnected: Service Bound");
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
            mBound = false;
            Log.d(TAG, "onServiceDisconnected: Service Disconnected");
        }
    };

    void stopService() {
        mBluetoothLeService.close();

        Intent bleServiceIntent = new Intent(mContext, bleService.class);
        mContext.stopService(bleServiceIntent);

        mContext.unbindService(mServiceConnection);
    }

    void startRecording() {
        mBluetoothLeService.startRecording();
    }

    void stopRecording() {
        mBluetoothLeService.stopRecording();
    }
}
