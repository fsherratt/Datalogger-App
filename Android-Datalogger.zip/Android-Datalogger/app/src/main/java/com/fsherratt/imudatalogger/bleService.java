package com.fsherratt.imudatalogger;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class bleService extends Service {
    private String TAG = "bleService";

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    private int mConnectionState = STATE_DISCONNECTED;

    private Semaphore mWriteSemaphore = new Semaphore(1, true);

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;

    public final static String ACTION_GATT_CONNECTED = "com.fsherratt.imudatalogger.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED = "com.fsherratt.imudatalogger.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED = "com.fsherratt.imudatalogger.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE = "com.fsherratt.imudatalogger.ACTION_DATA_AVAILABLE";

    public final static String EXTRA_UUID = "com.fsherratt.imudatalogger.EXTRA_UUID";
    public final static String EXTRA_DATA = "com.fsherratt.imudatalogger.EXTRA_DATA";
    public final static String EXTRA_NAME = "com.fsherratt.imudatalogger.EXTRA_NAME";
    public final static String EXTRA_ADDRESS = "com.example.fsherratt.imudatalogger.EXTRA_ADDRESS";

    @Override
    public void onDestroy() {
        super.onDestroy();

        close();

        Log.d(TAG, "onDestroy: Service Destroyed");
    }


    private final IBinder mBinder = new LocalBinder();

    public class LocalBinder extends Binder {
        bleService getService() {
            return bleService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        mDeviceAddress = intent.getStringExtra(EXTRA_ADDRESS);
        TAG = TAG + "-" + mDeviceAddress;

        Log.d(TAG, "onBind: Service bound for address: " + mDeviceAddress);

        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }



    public boolean initialize() {
        Log.d(TAG, "initialize: Called");
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    public boolean connect() {
        Log.d(TAG, "connect: Starting connection");
        if (mBluetoothAdapter == null || mDeviceAddress == null) {
            Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(mDeviceAddress);
        if (device == null) {
            Log.w(TAG, "Device not found.  Unable to connect.");
            return false;
        }

        Log.d(TAG, "connect: Found device");

        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        mBluetoothGatt = device.connectGatt(this, false, mGattCallback);
        Log.d(TAG, "Trying to create a new connection.");

        mConnectionState = STATE_CONNECTING;
        return true;
    }

    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.disconnect();
    }

    public void close() {
        disconnect();

        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;

        broadcastUpdate(ACTION_GATT_DISCONNECTED);
    }


    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            String intentAction;
            if (newState == BluetoothProfile.STATE_CONNECTED) {

                mConnectionState = STATE_CONNECTED;

                mBluetoothGatt.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH);

                intentAction = ACTION_GATT_CONNECTED;
                broadcastUpdate(intentAction);

                Log.i(TAG, "Connected to GATT server.");
                // Attempts to discover services after successful connection.
                Log.i(TAG, "Attempting to start service discovery:" +
                        mBluetoothGatt.discoverServices());

            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                intentAction = ACTION_GATT_DISCONNECTED;

                mConnectionState = STATE_DISCONNECTED;
                broadcastUpdate(intentAction);

                Log.i(TAG, "Disconnected from GATT server.");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(TAG, "onServicesDiscovered: Services discovered");

                characteristicDiscovery();
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicRead(gatt, characteristic, status);
            Log.d(TAG, "onCharacteristicRead: Read status = " + String.valueOf( status ) );

            if (status == BluetoothGatt.GATT_SUCCESS) {
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }

            mWriteSemaphore.release();
            Log.d(TAG, "onCharacteristicRead: semaphore released");
        }

        @Override
        public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
            super.onCharacteristicWrite(gatt, characteristic, status);
            Log.d(TAG, "onCharacteristicWrite: Write status = " + String.valueOf( status ) );

            mWriteSemaphore.release();
            Log.d(TAG, "onCharacteristicWrite: semaphore released");
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            super.onDescriptorWrite(gatt, descriptor, status);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);
            broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);

//            Log.d(TAG, "onCharacteristicChanged: UUID: " + characteristic.getUuid());
        }
    };

    private void broadcastUpdate(final String action) {
        final Intent intent = new Intent(action);
        intent.putExtra(EXTRA_ADDRESS, mDeviceAddress);
        sendBroadcast(intent);
    }

    private void broadcastUpdate(final String action, final BluetoothGattCharacteristic characteristic) {
        final Intent intent = new Intent(action);

        if (action.equals(ACTION_DATA_AVAILABLE) ) {
            intent.putExtra(EXTRA_ADDRESS, mDeviceAddress);
            intent.putExtra(EXTRA_UUID, characteristic.getUuid().toString());
            intent.putExtra(EXTRA_DATA, characteristic.getValue());
        }

        sendBroadcast(intent);
    }


    List<BluetoothGattCharacteristic> mNotifyCharacteristics = new ArrayList<>();

    private void characteristicDiscovery() {
        List<UUID> notifiableCharacteristics = new ArrayList<>();
        notifiableCharacteristics.add(UUID.fromString("00000001-0000-1000-8000-00805f9b34fb"));
        notifiableCharacteristics.add(UUID.fromString("00000002-0000-1000-8000-00805f9b34fb"));

        for ( BluetoothGattService service : mBluetoothGatt.getServices() ) {
            for ( BluetoothGattCharacteristic characteristic : service.getCharacteristics() ) {
                if ( notifiableCharacteristics.contains(characteristic.getUuid())) {
                    mNotifyCharacteristics.add(characteristic);

                    Log.d(TAG, "CharacteristicDiscovery: Found characteristic " + characteristic.getUuid());
                }
            }
        }

        if ( mNotifyCharacteristics.size() != 2 )
        {
            Log.e(TAG, "CharacteristicDiscovery: Not all charcteristics found: " + mNotifyCharacteristics.size());
        }

        broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
    }

    public void setCharacteristicNotifications( boolean enable ) {
        for ( BluetoothGattCharacteristic notifyChar : mNotifyCharacteristics ) {
            setCharacteristicNotification(notifyChar, enable);
        }
    }

    public boolean setCharacteristicNotification(BluetoothGattCharacteristic characteristic, boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(TAG, "setCharacteristicNotification: BluetoothAdapter not initialized");
            return false;
        }

        // Request write lock
        try {
            mWriteSemaphore.tryAcquire(1000, TimeUnit.MILLISECONDS);
        } catch ( InterruptedException e ) {
            Log.e(TAG, e.getMessage() );
            return false;
        }

        final String CLIENT_CHARACTERISTIC_CONFIG = "00002902-0000-1000-8000-00805f9b34fb";
        // Enable on client device
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor( UUID.fromString(CLIENT_CHARACTERISTIC_CONFIG) );

        if (descriptor == null) {
            return false;
        }

        // Enable on android
        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        if (enabled) {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        } else {
            descriptor.setValue(BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE);
        }

        mBluetoothGatt.writeDescriptor(descriptor);
        Log.d(TAG, "setCharacteristicNotification: notification set");

        return true;
    }


    public void startRecording() {
        setCharacteristicNotifications(true);
    }

    public void stopRecording() {
        setCharacteristicNotifications(false);
    }


 }

// EOF
