package com.fsherratt.imudatalogger;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

public class logService extends Service {
    private static final String TAG = "logService";

    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        logService getService() {
            // Return this instance of LocalService so clients can call public methods
            return logService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    // Incoming BLE data
    private void startReceiver() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(MainActivity.ACTION_KEYFRAME_LABEL);
        intentFilter.addAction(bleService.ACTION_DATA_AVAILABLE);

        try {
            registerReceiver(mLogDataReceiver, intentFilter);
            Log.d(TAG, "startReceiver: ACTION_DATA_AVAILABLE receiver listening");
        } catch(IllegalArgumentException e) {
            Log.e(TAG, "Receiver already registered");
        }
    }

    private void stopReceiver() {
        try {
            unregisterReceiver(mLogDataReceiver);
            Log.d(TAG, "stopReceiver: ACTION_DATA_AVAILABLE receiver stopped");
        } catch(IllegalArgumentException e) {
            Log.e(TAG, "Receiver not registered");
        }
    }

    private final BroadcastReceiver mLogDataReceiver; {
        mLogDataReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                final String action = intent.getAction();
                Log.d(TAG, "onReceive: " + action);

                if ( action.equals(bleService.ACTION_DATA_AVAILABLE)) {
                    String Address = intent.getStringExtra(bleService.EXTRA_ADDRESS);
                    String Uuid = intent.getStringExtra(bleService.EXTRA_UUID);
                    byte data[] = intent.getByteArrayExtra(bleService.EXTRA_DATA);

                    Log.d(TAG, "onReceive: " + Address + " - " + Uuid);

                }
                else if ( action.equals(MainActivity.ACTION_KEYFRAME_LABEL)) {
                    String label = intent.getStringExtra(MainActivity.EXTRA_LABEL);
                    String timestamp = intent.getStringExtra(MainActivity.EXTRA_TIMESTAMP);

                    Log.d(TAG, "onRecieve: ACTION_KEYFRAME_LABEL " + label);
                }
            }
        };
    }

}
